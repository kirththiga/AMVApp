import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class additionCartesianTest {
	
	//Missing an input
	@Test
	public void checkMissingInputForAddTwo() {
		String x1, y1, x2, y2, result;
		x1 = "";
		y1 = "2";
		x2 = "3";
		y2 = "4";
		
		result = "Missing an input or inputs";
		assertEquals(result, additionCartesian.vectorAddTwoResult(x1, y1, x2, y2));

		x1 = "1";
		y1 = "";
		x2 = "3";
		y2 = "4";
		
		assertEquals(result, additionCartesian.vectorAddTwoResult(x1, y1, x2, y2));
		
		x1 = "1";
		y1 = "2";
		x2 = "";
		y2 = "4";
		
		assertEquals(result, additionCartesian.vectorAddTwoResult(x1, y1, x2, y2));
		
		x1 = "1";
		y1 = "";
		x2 = "3";
		y2 = "4";
		
		assertEquals(result, additionCartesian.vectorAddTwoResult(x1, y1, x2, y2));
		
		x1 = "1";
		y1 = "2";
		x2 = "3";
		y2 = "";
		
		assertEquals(result, additionCartesian.vectorAddTwoResult(x1, y1, x2, y2));
		
		x1 = "1";
		y1 = "";
		x2 = "";
		y2 = "4";
		
		assertEquals(result, additionCartesian.vectorAddTwoResult(x1, y1, x2, y2));
	}
	
	//Testing with all valid inputs
	@Test
	public void checkValidInputsForAddTwo() {
		String x1, y1, x2, y2;
		x1 = "1";
		y1 = "2";
		x2 = "3";
		y2 = "4";
		
		String result = "(4.0, 6.0)";
		assertEquals(result, additionCartesian.vectorAddTwoResult(x1, y1, x2, y2));
	}

}
